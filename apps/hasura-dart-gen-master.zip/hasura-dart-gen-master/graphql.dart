import 'package:flutter/material.dart' show TimeOfDay;
import 'package:json_annotation/json_annotation.dart';
part 'graphql.g.dart';

@JsonSerializable()
class GQLQueryData {
    @JsonKey(name: 'educations',)
    List<Education> educations;
    @JsonKey(name: 'educations_by_pk',)
    Education educationsByPk;
    @JsonKey(name: 'educations_aggregate',)
    EducationsAggregate educationsAggregate;
    @JsonKey(name: 'occupations',)
    List<Occupation> occupations;
    @JsonKey(name: 'occupations_by_pk',)
    Occupation occupationsByPk;
    @JsonKey(name: 'occupations_aggregate',)
    OccupationsAggregate occupationsAggregate;
    @JsonKey(name: 'places',)
    List<Place> places;
    @JsonKey(name: 'places_by_pk',)
    Place placesByPk;
    @JsonKey(name: 'places_aggregate',)
    PlacesAggregate placesAggregate;
    @JsonKey(name: 'relations',)
    List<Relation> relations;
    @JsonKey(name: 'relations_by_pk',)
    Relation relationsByPk;
    @JsonKey(name: 'relations_aggregate',)
    RelationsAggregate relationsAggregate;
    @JsonKey(name: 'user_approval_requests',)
    List<UserApprovalRequest> userApprovalRequests;
    @JsonKey(name: 'user_approval_requests_by_pk',)
    UserApprovalRequest userApprovalRequestsByPk;
    @JsonKey(name: 'user_approval_requests_aggregate',)
    UserApprovalRequestsAggregate userApprovalRequestsAggregate;
    @JsonKey(name: 'user_educations',)
    List<UserEducation> userEducations;
    @JsonKey(name: 'user_educations_by_pk',)
    UserEducation userEducationsByPk;
    @JsonKey(name: 'user_educations_aggregate',)
    UserEducationsAggregate userEducationsAggregate;
    @JsonKey(name: 'user_families',)
    List<UserFamily> userFamilies;
    @JsonKey(name: 'user_families_by_pk',)
    UserFamily userFamiliesByPk;
    @JsonKey(name: 'user_families_aggregate',)
    UserFamiliesAggregate userFamiliesAggregate;
    @JsonKey(name: 'user_occupations',)
    List<UserOccupation> userOccupations;
    @JsonKey(name: 'user_occupations_by_pk',)
    UserOccupation userOccupationsByPk;
    @JsonKey(name: 'user_occupations_aggregate',)
    UserOccupationsAggregate userOccupationsAggregate;
    @JsonKey(name: 'users',)
    List<User> users;
    @JsonKey(name: 'users_by_pk',)
    User usersByPk;
    @JsonKey(name: 'users_aggregate',)
    UsersAggregate usersAggregate;

    GQLQueryData({
        this.educations,            
        this.educationsByPk,            
        this.educationsAggregate,            
        this.occupations,            
        this.occupationsByPk,            
        this.occupationsAggregate,            
        this.places,            
        this.placesByPk,            
        this.placesAggregate,            
        this.relations,            
        this.relationsByPk,            
        this.relationsAggregate,            
        this.userApprovalRequests,            
        this.userApprovalRequestsByPk,            
        this.userApprovalRequestsAggregate,            
        this.userEducations,            
        this.userEducationsByPk,            
        this.userEducationsAggregate,            
        this.userFamilies,            
        this.userFamiliesByPk,            
        this.userFamiliesAggregate,            
        this.userOccupations,            
        this.userOccupationsByPk,            
        this.userOccupationsAggregate,            
        this.users,            
        this.usersByPk,            
        this.usersAggregate,            
    });

    factory GQLQueryData.fromJson(Map<String, dynamic> json) => _$GQLQueryDataFromJson(json);
}

@JsonSerializable()
class Education {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    Education({
        this.id,            
        this.name,            
    });

    factory Education.fromJson(Map<String, dynamic> json) => _$EducationFromJson(json);
}

@JsonSerializable()
class EducationsAggregate {
    @JsonKey(name: 'nodes',)
    List<Education> nodes;
    @JsonKey(name: 'aggregate',)
    EducationsAggregateField aggregate;

    EducationsAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory EducationsAggregate.fromJson(Map<String, dynamic> json) => _$EducationsAggregateFromJson(json);
}

@JsonSerializable()
class EducationsAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    EducationsAvgField avg;
    @JsonKey(name: 'max',)
    EducationsMaxField max;
    @JsonKey(name: 'min',)
    EducationsMinField min;
    @JsonKey(name: 'stddev',)
    EducationsStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    EducationsStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    EducationsStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    EducationsSumField sum;
    @JsonKey(name: 'var_pop',)
    EducationsVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    EducationsVarSampField varSamp;
    @JsonKey(name: 'variance',)
    EducationsVarianceField variance;

    EducationsAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory EducationsAggregateField.fromJson(Map<String, dynamic> json) => _$EducationsAggregateFieldFromJson(json);
}

@JsonSerializable()
class EducationsAvgField {
    @JsonKey(name: 'id',)
    double id;

    EducationsAvgField({
        this.id,            
    });

    factory EducationsAvgField.fromJson(Map<String, dynamic> json) => _$EducationsAvgFieldFromJson(json);
}

@JsonSerializable()
class EducationsMaxField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    EducationsMaxField({
        this.id,            
        this.name,            
    });

    factory EducationsMaxField.fromJson(Map<String, dynamic> json) => _$EducationsMaxFieldFromJson(json);
}

@JsonSerializable()
class EducationsMinField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    EducationsMinField({
        this.id,            
        this.name,            
    });

    factory EducationsMinField.fromJson(Map<String, dynamic> json) => _$EducationsMinFieldFromJson(json);
}

@JsonSerializable()
class EducationsStddevField {
    @JsonKey(name: 'id',)
    double id;

    EducationsStddevField({
        this.id,            
    });

    factory EducationsStddevField.fromJson(Map<String, dynamic> json) => _$EducationsStddevFieldFromJson(json);
}

@JsonSerializable()
class EducationsStddevPopField {
    @JsonKey(name: 'id',)
    double id;

    EducationsStddevPopField({
        this.id,            
    });

    factory EducationsStddevPopField.fromJson(Map<String, dynamic> json) => _$EducationsStddevPopFieldFromJson(json);
}

@JsonSerializable()
class EducationsStddevSampField {
    @JsonKey(name: 'id',)
    double id;

    EducationsStddevSampField({
        this.id,            
    });

    factory EducationsStddevSampField.fromJson(Map<String, dynamic> json) => _$EducationsStddevSampFieldFromJson(json);
}

@JsonSerializable()
class EducationsSumField {
    @JsonKey(name: 'id',)
    int id;

    EducationsSumField({
        this.id,            
    });

    factory EducationsSumField.fromJson(Map<String, dynamic> json) => _$EducationsSumFieldFromJson(json);
}

@JsonSerializable()
class EducationsVarPopField {
    @JsonKey(name: 'id',)
    double id;

    EducationsVarPopField({
        this.id,            
    });

    factory EducationsVarPopField.fromJson(Map<String, dynamic> json) => _$EducationsVarPopFieldFromJson(json);
}

@JsonSerializable()
class EducationsVarSampField {
    @JsonKey(name: 'id',)
    double id;

    EducationsVarSampField({
        this.id,            
    });

    factory EducationsVarSampField.fromJson(Map<String, dynamic> json) => _$EducationsVarSampFieldFromJson(json);
}

@JsonSerializable()
class EducationsVarianceField {
    @JsonKey(name: 'id',)
    double id;

    EducationsVarianceField({
        this.id,            
    });

    factory EducationsVarianceField.fromJson(Map<String, dynamic> json) => _$EducationsVarianceFieldFromJson(json);
}

@JsonSerializable()
class Occupation {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    Occupation({
        this.id,            
        this.name,            
    });

    factory Occupation.fromJson(Map<String, dynamic> json) => _$OccupationFromJson(json);
}

@JsonSerializable()
class OccupationsAggregate {
    @JsonKey(name: 'nodes',)
    List<Occupation> nodes;
    @JsonKey(name: 'aggregate',)
    OccupationsAggregateField aggregate;

    OccupationsAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory OccupationsAggregate.fromJson(Map<String, dynamic> json) => _$OccupationsAggregateFromJson(json);
}

@JsonSerializable()
class OccupationsAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    OccupationsAvgField avg;
    @JsonKey(name: 'max',)
    OccupationsMaxField max;
    @JsonKey(name: 'min',)
    OccupationsMinField min;
    @JsonKey(name: 'stddev',)
    OccupationsStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    OccupationsStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    OccupationsStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    OccupationsSumField sum;
    @JsonKey(name: 'var_pop',)
    OccupationsVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    OccupationsVarSampField varSamp;
    @JsonKey(name: 'variance',)
    OccupationsVarianceField variance;

    OccupationsAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory OccupationsAggregateField.fromJson(Map<String, dynamic> json) => _$OccupationsAggregateFieldFromJson(json);
}

@JsonSerializable()
class OccupationsAvgField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsAvgField({
        this.id,            
    });

    factory OccupationsAvgField.fromJson(Map<String, dynamic> json) => _$OccupationsAvgFieldFromJson(json);
}

@JsonSerializable()
class OccupationsMaxField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    OccupationsMaxField({
        this.id,            
        this.name,            
    });

    factory OccupationsMaxField.fromJson(Map<String, dynamic> json) => _$OccupationsMaxFieldFromJson(json);
}

@JsonSerializable()
class OccupationsMinField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    OccupationsMinField({
        this.id,            
        this.name,            
    });

    factory OccupationsMinField.fromJson(Map<String, dynamic> json) => _$OccupationsMinFieldFromJson(json);
}

@JsonSerializable()
class OccupationsStddevField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsStddevField({
        this.id,            
    });

    factory OccupationsStddevField.fromJson(Map<String, dynamic> json) => _$OccupationsStddevFieldFromJson(json);
}

@JsonSerializable()
class OccupationsStddevPopField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsStddevPopField({
        this.id,            
    });

    factory OccupationsStddevPopField.fromJson(Map<String, dynamic> json) => _$OccupationsStddevPopFieldFromJson(json);
}

@JsonSerializable()
class OccupationsStddevSampField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsStddevSampField({
        this.id,            
    });

    factory OccupationsStddevSampField.fromJson(Map<String, dynamic> json) => _$OccupationsStddevSampFieldFromJson(json);
}

@JsonSerializable()
class OccupationsSumField {
    @JsonKey(name: 'id',)
    int id;

    OccupationsSumField({
        this.id,            
    });

    factory OccupationsSumField.fromJson(Map<String, dynamic> json) => _$OccupationsSumFieldFromJson(json);
}

@JsonSerializable()
class OccupationsVarPopField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsVarPopField({
        this.id,            
    });

    factory OccupationsVarPopField.fromJson(Map<String, dynamic> json) => _$OccupationsVarPopFieldFromJson(json);
}

@JsonSerializable()
class OccupationsVarSampField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsVarSampField({
        this.id,            
    });

    factory OccupationsVarSampField.fromJson(Map<String, dynamic> json) => _$OccupationsVarSampFieldFromJson(json);
}

@JsonSerializable()
class OccupationsVarianceField {
    @JsonKey(name: 'id',)
    double id;

    OccupationsVarianceField({
        this.id,            
    });

    factory OccupationsVarianceField.fromJson(Map<String, dynamic> json) => _$OccupationsVarianceFieldFromJson(json);
}

@JsonSerializable()
class Place {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;
    @JsonKey(name: 'id',)
    String id;
    @JsonKey(name: 'name',)
    String name;

    Place({
        this.hasuraBugTmpField,            
        this.id,            
        this.name,            
    });

    factory Place.fromJson(Map<String, dynamic> json) => _$PlaceFromJson(json);
}

@JsonSerializable()
class PlacesAggregate {
    @JsonKey(name: 'nodes',)
    List<Place> nodes;
    @JsonKey(name: 'aggregate',)
    PlacesAggregateField aggregate;

    PlacesAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory PlacesAggregate.fromJson(Map<String, dynamic> json) => _$PlacesAggregateFromJson(json);
}

@JsonSerializable()
class PlacesAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    PlacesAvgField avg;
    @JsonKey(name: 'max',)
    PlacesMaxField max;
    @JsonKey(name: 'min',)
    PlacesMinField min;
    @JsonKey(name: 'stddev',)
    PlacesStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    PlacesStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    PlacesStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    PlacesSumField sum;
    @JsonKey(name: 'var_pop',)
    PlacesVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    PlacesVarSampField varSamp;
    @JsonKey(name: 'variance',)
    PlacesVarianceField variance;

    PlacesAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory PlacesAggregateField.fromJson(Map<String, dynamic> json) => _$PlacesAggregateFieldFromJson(json);
}

@JsonSerializable()
class PlacesAvgField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesAvgField({
        this.hasuraBugTmpField,            
    });

    factory PlacesAvgField.fromJson(Map<String, dynamic> json) => _$PlacesAvgFieldFromJson(json);
}

@JsonSerializable()
class PlacesMaxField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;
    @JsonKey(name: 'id',)
    String id;
    @JsonKey(name: 'name',)
    String name;

    PlacesMaxField({
        this.hasuraBugTmpField,            
        this.id,            
        this.name,            
    });

    factory PlacesMaxField.fromJson(Map<String, dynamic> json) => _$PlacesMaxFieldFromJson(json);
}

@JsonSerializable()
class PlacesMinField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;
    @JsonKey(name: 'id',)
    String id;
    @JsonKey(name: 'name',)
    String name;

    PlacesMinField({
        this.hasuraBugTmpField,            
        this.id,            
        this.name,            
    });

    factory PlacesMinField.fromJson(Map<String, dynamic> json) => _$PlacesMinFieldFromJson(json);
}

@JsonSerializable()
class PlacesStddevField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesStddevField({
        this.hasuraBugTmpField,            
    });

    factory PlacesStddevField.fromJson(Map<String, dynamic> json) => _$PlacesStddevFieldFromJson(json);
}

@JsonSerializable()
class PlacesStddevPopField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesStddevPopField({
        this.hasuraBugTmpField,            
    });

    factory PlacesStddevPopField.fromJson(Map<String, dynamic> json) => _$PlacesStddevPopFieldFromJson(json);
}

@JsonSerializable()
class PlacesStddevSampField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesStddevSampField({
        this.hasuraBugTmpField,            
    });

    factory PlacesStddevSampField.fromJson(Map<String, dynamic> json) => _$PlacesStddevSampFieldFromJson(json);
}

@JsonSerializable()
class PlacesSumField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;

    PlacesSumField({
        this.hasuraBugTmpField,            
    });

    factory PlacesSumField.fromJson(Map<String, dynamic> json) => _$PlacesSumFieldFromJson(json);
}

@JsonSerializable()
class PlacesVarPopField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesVarPopField({
        this.hasuraBugTmpField,            
    });

    factory PlacesVarPopField.fromJson(Map<String, dynamic> json) => _$PlacesVarPopFieldFromJson(json);
}

@JsonSerializable()
class PlacesVarSampField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesVarSampField({
        this.hasuraBugTmpField,            
    });

    factory PlacesVarSampField.fromJson(Map<String, dynamic> json) => _$PlacesVarSampFieldFromJson(json);
}

@JsonSerializable()
class PlacesVarianceField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    PlacesVarianceField({
        this.hasuraBugTmpField,            
    });

    factory PlacesVarianceField.fromJson(Map<String, dynamic> json) => _$PlacesVarianceFieldFromJson(json);
}

@JsonSerializable()
class Relation {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    Relation({
        this.id,            
        this.name,            
    });

    factory Relation.fromJson(Map<String, dynamic> json) => _$RelationFromJson(json);
}

@JsonSerializable()
class RelationsAggregate {
    @JsonKey(name: 'nodes',)
    List<Relation> nodes;
    @JsonKey(name: 'aggregate',)
    RelationsAggregateField aggregate;

    RelationsAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory RelationsAggregate.fromJson(Map<String, dynamic> json) => _$RelationsAggregateFromJson(json);
}

@JsonSerializable()
class RelationsAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    RelationsAvgField avg;
    @JsonKey(name: 'max',)
    RelationsMaxField max;
    @JsonKey(name: 'min',)
    RelationsMinField min;
    @JsonKey(name: 'stddev',)
    RelationsStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    RelationsStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    RelationsStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    RelationsSumField sum;
    @JsonKey(name: 'var_pop',)
    RelationsVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    RelationsVarSampField varSamp;
    @JsonKey(name: 'variance',)
    RelationsVarianceField variance;

    RelationsAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory RelationsAggregateField.fromJson(Map<String, dynamic> json) => _$RelationsAggregateFieldFromJson(json);
}

@JsonSerializable()
class RelationsAvgField {
    @JsonKey(name: 'id',)
    double id;

    RelationsAvgField({
        this.id,            
    });

    factory RelationsAvgField.fromJson(Map<String, dynamic> json) => _$RelationsAvgFieldFromJson(json);
}

@JsonSerializable()
class RelationsMaxField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    RelationsMaxField({
        this.id,            
        this.name,            
    });

    factory RelationsMaxField.fromJson(Map<String, dynamic> json) => _$RelationsMaxFieldFromJson(json);
}

@JsonSerializable()
class RelationsMinField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'name',)
    String name;

    RelationsMinField({
        this.id,            
        this.name,            
    });

    factory RelationsMinField.fromJson(Map<String, dynamic> json) => _$RelationsMinFieldFromJson(json);
}

@JsonSerializable()
class RelationsStddevField {
    @JsonKey(name: 'id',)
    double id;

    RelationsStddevField({
        this.id,            
    });

    factory RelationsStddevField.fromJson(Map<String, dynamic> json) => _$RelationsStddevFieldFromJson(json);
}

@JsonSerializable()
class RelationsStddevPopField {
    @JsonKey(name: 'id',)
    double id;

    RelationsStddevPopField({
        this.id,            
    });

    factory RelationsStddevPopField.fromJson(Map<String, dynamic> json) => _$RelationsStddevPopFieldFromJson(json);
}

@JsonSerializable()
class RelationsStddevSampField {
    @JsonKey(name: 'id',)
    double id;

    RelationsStddevSampField({
        this.id,            
    });

    factory RelationsStddevSampField.fromJson(Map<String, dynamic> json) => _$RelationsStddevSampFieldFromJson(json);
}

@JsonSerializable()
class RelationsSumField {
    @JsonKey(name: 'id',)
    int id;

    RelationsSumField({
        this.id,            
    });

    factory RelationsSumField.fromJson(Map<String, dynamic> json) => _$RelationsSumFieldFromJson(json);
}

@JsonSerializable()
class RelationsVarPopField {
    @JsonKey(name: 'id',)
    double id;

    RelationsVarPopField({
        this.id,            
    });

    factory RelationsVarPopField.fromJson(Map<String, dynamic> json) => _$RelationsVarPopFieldFromJson(json);
}

@JsonSerializable()
class RelationsVarSampField {
    @JsonKey(name: 'id',)
    double id;

    RelationsVarSampField({
        this.id,            
    });

    factory RelationsVarSampField.fromJson(Map<String, dynamic> json) => _$RelationsVarSampFieldFromJson(json);
}

@JsonSerializable()
class RelationsVarianceField {
    @JsonKey(name: 'id',)
    double id;

    RelationsVarianceField({
        this.id,            
    });

    factory RelationsVarianceField.fromJson(Map<String, dynamic> json) => _$RelationsVarianceFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequest {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;
    @JsonKey(name: 'requested_user_id',)
    String requestedUserId;
    @JsonKey(name: 'user_id',)
    String userId;

    UserApprovalRequest({
        this.hasuraBugTmpField,            
        this.requestedUserId,            
        this.userId,            
    });

    factory UserApprovalRequest.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsAggregate {
    @JsonKey(name: 'nodes',)
    List<UserApprovalRequest> nodes;
    @JsonKey(name: 'aggregate',)
    UserApprovalRequestsAggregateField aggregate;

    UserApprovalRequestsAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory UserApprovalRequestsAggregate.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsAggregateFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    UserApprovalRequestsAvgField avg;
    @JsonKey(name: 'max',)
    UserApprovalRequestsMaxField max;
    @JsonKey(name: 'min',)
    UserApprovalRequestsMinField min;
    @JsonKey(name: 'stddev',)
    UserApprovalRequestsStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    UserApprovalRequestsStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    UserApprovalRequestsStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    UserApprovalRequestsSumField sum;
    @JsonKey(name: 'var_pop',)
    UserApprovalRequestsVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    UserApprovalRequestsVarSampField varSamp;
    @JsonKey(name: 'variance',)
    UserApprovalRequestsVarianceField variance;

    UserApprovalRequestsAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory UserApprovalRequestsAggregateField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsAggregateFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsAvgField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsAvgField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsAvgField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsAvgFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsMaxField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;
    @JsonKey(name: 'requested_user_id',)
    String requestedUserId;
    @JsonKey(name: 'user_id',)
    String userId;

    UserApprovalRequestsMaxField({
        this.hasuraBugTmpField,            
        this.requestedUserId,            
        this.userId,            
    });

    factory UserApprovalRequestsMaxField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsMaxFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsMinField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;
    @JsonKey(name: 'requested_user_id',)
    String requestedUserId;
    @JsonKey(name: 'user_id',)
    String userId;

    UserApprovalRequestsMinField({
        this.hasuraBugTmpField,            
        this.requestedUserId,            
        this.userId,            
    });

    factory UserApprovalRequestsMinField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsMinFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsStddevField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsStddevField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsStddevField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsStddevFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsStddevPopField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsStddevPopField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsStddevPopField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsStddevPopFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsStddevSampField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsStddevSampField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsStddevSampField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsStddevSampFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsSumField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    int hasuraBugTmpField;

    UserApprovalRequestsSumField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsSumField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsSumFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsVarPopField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsVarPopField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsVarPopField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsVarPopFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsVarSampField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsVarSampField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsVarSampField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsVarSampFieldFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsVarianceField {
    @JsonKey(name: 'hasura_bug_tmp_field',)
    double hasuraBugTmpField;

    UserApprovalRequestsVarianceField({
        this.hasuraBugTmpField,            
    });

    factory UserApprovalRequestsVarianceField.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsVarianceFieldFromJson(json);
}

@JsonSerializable()
class UserEducation {
    @JsonKey(name: 'education_id',)
    int educationId;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'user_id',)
    String userId;
    @JsonKey(name: 'education',)
    Education education;

    UserEducation({
        this.educationId,            
        this.id,            
        this.userId,            
        this.education,            
    });

    factory UserEducation.fromJson(Map<String, dynamic> json) => _$UserEducationFromJson(json);
}

@JsonSerializable()
class UserEducationsAggregate {
    @JsonKey(name: 'nodes',)
    List<UserEducation> nodes;
    @JsonKey(name: 'aggregate',)
    UserEducationsAggregateField aggregate;

    UserEducationsAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory UserEducationsAggregate.fromJson(Map<String, dynamic> json) => _$UserEducationsAggregateFromJson(json);
}

@JsonSerializable()
class UserEducationsAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    UserEducationsAvgField avg;
    @JsonKey(name: 'max',)
    UserEducationsMaxField max;
    @JsonKey(name: 'min',)
    UserEducationsMinField min;
    @JsonKey(name: 'stddev',)
    UserEducationsStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    UserEducationsStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    UserEducationsStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    UserEducationsSumField sum;
    @JsonKey(name: 'var_pop',)
    UserEducationsVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    UserEducationsVarSampField varSamp;
    @JsonKey(name: 'variance',)
    UserEducationsVarianceField variance;

    UserEducationsAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory UserEducationsAggregateField.fromJson(Map<String, dynamic> json) => _$UserEducationsAggregateFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsAvgField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsAvgField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsAvgField.fromJson(Map<String, dynamic> json) => _$UserEducationsAvgFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsMaxField {
    @JsonKey(name: 'education_id',)
    int educationId;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'user_id',)
    String userId;

    UserEducationsMaxField({
        this.educationId,            
        this.id,            
        this.userId,            
    });

    factory UserEducationsMaxField.fromJson(Map<String, dynamic> json) => _$UserEducationsMaxFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsMinField {
    @JsonKey(name: 'education_id',)
    int educationId;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'user_id',)
    String userId;

    UserEducationsMinField({
        this.educationId,            
        this.id,            
        this.userId,            
    });

    factory UserEducationsMinField.fromJson(Map<String, dynamic> json) => _$UserEducationsMinFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsStddevField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsStddevField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsStddevField.fromJson(Map<String, dynamic> json) => _$UserEducationsStddevFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsStddevPopField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsStddevPopField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsStddevPopField.fromJson(Map<String, dynamic> json) => _$UserEducationsStddevPopFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsStddevSampField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsStddevSampField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsStddevSampField.fromJson(Map<String, dynamic> json) => _$UserEducationsStddevSampFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsSumField {
    @JsonKey(name: 'education_id',)
    int educationId;
    @JsonKey(name: 'id',)
    int id;

    UserEducationsSumField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsSumField.fromJson(Map<String, dynamic> json) => _$UserEducationsSumFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsVarPopField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsVarPopField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsVarPopField.fromJson(Map<String, dynamic> json) => _$UserEducationsVarPopFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsVarSampField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsVarSampField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsVarSampField.fromJson(Map<String, dynamic> json) => _$UserEducationsVarSampFieldFromJson(json);
}

@JsonSerializable()
class UserEducationsVarianceField {
    @JsonKey(name: 'education_id',)
    double educationId;
    @JsonKey(name: 'id',)
    double id;

    UserEducationsVarianceField({
        this.educationId,            
        this.id,            
    });

    factory UserEducationsVarianceField.fromJson(Map<String, dynamic> json) => _$UserEducationsVarianceFieldFromJson(json);
}

@JsonSerializable()
class UserFamily {
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'relation_id',)
    int relationId;
    @JsonKey(name: 'first_name',)
    String firstName;
    @JsonKey(name: 'last_name',)
    String lastName;
    @JsonKey(name: 'middle_name',)
    String middleName;
    @JsonKey(name: 'phone',)
    String phone;
    @JsonKey(name: 'user_id',)
    String userId;
    @JsonKey(name: 'birth_date',)
    DateTime birthDate;
    @JsonKey(name: 'relation',)
    Relation relation;

    UserFamily({
        this.gender,            
        this.id,            
        this.relationId,            
        this.firstName,            
        this.lastName,            
        this.middleName,            
        this.phone,            
        this.userId,            
        this.birthDate,            
        this.relation,            
    });

    factory UserFamily.fromJson(Map<String, dynamic> json) => _$UserFamilyFromJson(json);
}

@JsonSerializable()
class UserFamiliesAggregate {
    @JsonKey(name: 'nodes',)
    List<UserFamily> nodes;
    @JsonKey(name: 'aggregate',)
    UserFamiliesAggregateField aggregate;

    UserFamiliesAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory UserFamiliesAggregate.fromJson(Map<String, dynamic> json) => _$UserFamiliesAggregateFromJson(json);
}

@JsonSerializable()
class UserFamiliesAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    UserFamiliesAvgField avg;
    @JsonKey(name: 'max',)
    UserFamiliesMaxField max;
    @JsonKey(name: 'min',)
    UserFamiliesMinField min;
    @JsonKey(name: 'stddev',)
    UserFamiliesStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    UserFamiliesStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    UserFamiliesStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    UserFamiliesSumField sum;
    @JsonKey(name: 'var_pop',)
    UserFamiliesVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    UserFamiliesVarSampField varSamp;
    @JsonKey(name: 'variance',)
    UserFamiliesVarianceField variance;

    UserFamiliesAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory UserFamiliesAggregateField.fromJson(Map<String, dynamic> json) => _$UserFamiliesAggregateFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesAvgField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesAvgField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesAvgField.fromJson(Map<String, dynamic> json) => _$UserFamiliesAvgFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesMaxField {
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'relation_id',)
    int relationId;
    @JsonKey(name: 'first_name',)
    String firstName;
    @JsonKey(name: 'last_name',)
    String lastName;
    @JsonKey(name: 'middle_name',)
    String middleName;
    @JsonKey(name: 'phone',)
    String phone;
    @JsonKey(name: 'user_id',)
    String userId;
    @JsonKey(name: 'birth_date',)
    DateTime birthDate;

    UserFamiliesMaxField({
        this.gender,            
        this.id,            
        this.relationId,            
        this.firstName,            
        this.lastName,            
        this.middleName,            
        this.phone,            
        this.userId,            
        this.birthDate,            
    });

    factory UserFamiliesMaxField.fromJson(Map<String, dynamic> json) => _$UserFamiliesMaxFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesMinField {
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'relation_id',)
    int relationId;
    @JsonKey(name: 'first_name',)
    String firstName;
    @JsonKey(name: 'last_name',)
    String lastName;
    @JsonKey(name: 'middle_name',)
    String middleName;
    @JsonKey(name: 'phone',)
    String phone;
    @JsonKey(name: 'user_id',)
    String userId;
    @JsonKey(name: 'birth_date',)
    DateTime birthDate;

    UserFamiliesMinField({
        this.gender,            
        this.id,            
        this.relationId,            
        this.firstName,            
        this.lastName,            
        this.middleName,            
        this.phone,            
        this.userId,            
        this.birthDate,            
    });

    factory UserFamiliesMinField.fromJson(Map<String, dynamic> json) => _$UserFamiliesMinFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesStddevField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesStddevField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesStddevField.fromJson(Map<String, dynamic> json) => _$UserFamiliesStddevFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesStddevPopField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesStddevPopField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesStddevPopField.fromJson(Map<String, dynamic> json) => _$UserFamiliesStddevPopFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesStddevSampField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesStddevSampField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesStddevSampField.fromJson(Map<String, dynamic> json) => _$UserFamiliesStddevSampFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesSumField {
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'relation_id',)
    int relationId;

    UserFamiliesSumField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesSumField.fromJson(Map<String, dynamic> json) => _$UserFamiliesSumFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesVarPopField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesVarPopField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesVarPopField.fromJson(Map<String, dynamic> json) => _$UserFamiliesVarPopFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesVarSampField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesVarSampField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesVarSampField.fromJson(Map<String, dynamic> json) => _$UserFamiliesVarSampFieldFromJson(json);
}

@JsonSerializable()
class UserFamiliesVarianceField {
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'relation_id',)
    double relationId;

    UserFamiliesVarianceField({
        this.gender,            
        this.id,            
        this.relationId,            
    });

    factory UserFamiliesVarianceField.fromJson(Map<String, dynamic> json) => _$UserFamiliesVarianceFieldFromJson(json);
}

@JsonSerializable()
class UserOccupation {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'occupation_id',)
    int occupationId;
    @JsonKey(name: 'user_id',)
    String userId;
    @JsonKey(name: 'occupation',)
    Occupation occupation;

    UserOccupation({
        this.id,            
        this.occupationId,            
        this.userId,            
        this.occupation,            
    });

    factory UserOccupation.fromJson(Map<String, dynamic> json) => _$UserOccupationFromJson(json);
}

@JsonSerializable()
class UserOccupationsAggregate {
    @JsonKey(name: 'nodes',)
    List<UserOccupation> nodes;
    @JsonKey(name: 'aggregate',)
    UserOccupationsAggregateField aggregate;

    UserOccupationsAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory UserOccupationsAggregate.fromJson(Map<String, dynamic> json) => _$UserOccupationsAggregateFromJson(json);
}

@JsonSerializable()
class UserOccupationsAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    UserOccupationsAvgField avg;
    @JsonKey(name: 'max',)
    UserOccupationsMaxField max;
    @JsonKey(name: 'min',)
    UserOccupationsMinField min;
    @JsonKey(name: 'stddev',)
    UserOccupationsStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    UserOccupationsStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    UserOccupationsStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    UserOccupationsSumField sum;
    @JsonKey(name: 'var_pop',)
    UserOccupationsVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    UserOccupationsVarSampField varSamp;
    @JsonKey(name: 'variance',)
    UserOccupationsVarianceField variance;

    UserOccupationsAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory UserOccupationsAggregateField.fromJson(Map<String, dynamic> json) => _$UserOccupationsAggregateFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsAvgField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsAvgField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsAvgField.fromJson(Map<String, dynamic> json) => _$UserOccupationsAvgFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsMaxField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'occupation_id',)
    int occupationId;
    @JsonKey(name: 'user_id',)
    String userId;

    UserOccupationsMaxField({
        this.id,            
        this.occupationId,            
        this.userId,            
    });

    factory UserOccupationsMaxField.fromJson(Map<String, dynamic> json) => _$UserOccupationsMaxFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsMinField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'occupation_id',)
    int occupationId;
    @JsonKey(name: 'user_id',)
    String userId;

    UserOccupationsMinField({
        this.id,            
        this.occupationId,            
        this.userId,            
    });

    factory UserOccupationsMinField.fromJson(Map<String, dynamic> json) => _$UserOccupationsMinFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsStddevField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsStddevField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsStddevField.fromJson(Map<String, dynamic> json) => _$UserOccupationsStddevFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsStddevPopField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsStddevPopField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsStddevPopField.fromJson(Map<String, dynamic> json) => _$UserOccupationsStddevPopFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsStddevSampField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsStddevSampField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsStddevSampField.fromJson(Map<String, dynamic> json) => _$UserOccupationsStddevSampFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsSumField {
    @JsonKey(name: 'id',)
    int id;
    @JsonKey(name: 'occupation_id',)
    int occupationId;

    UserOccupationsSumField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsSumField.fromJson(Map<String, dynamic> json) => _$UserOccupationsSumFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsVarPopField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsVarPopField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsVarPopField.fromJson(Map<String, dynamic> json) => _$UserOccupationsVarPopFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsVarSampField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsVarSampField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsVarSampField.fromJson(Map<String, dynamic> json) => _$UserOccupationsVarSampFieldFromJson(json);
}

@JsonSerializable()
class UserOccupationsVarianceField {
    @JsonKey(name: 'id',)
    double id;
    @JsonKey(name: 'occupation_id',)
    double occupationId;

    UserOccupationsVarianceField({
        this.id,            
        this.occupationId,            
    });

    factory UserOccupationsVarianceField.fromJson(Map<String, dynamic> json) => _$UserOccupationsVarianceFieldFromJson(json);
}

@JsonSerializable()
class User {
    @JsonKey(name: 'is_approved',)
    bool isApproved;
    @JsonKey(name: 'is_registration_completed',)
    bool isRegistrationCompleted;
    @JsonKey(name: 'blood_group',)
    int bloodGroup;
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'marital_status',)
    int maritalStatus;
    @JsonKey(name: 'approved_by_user_id',)
    String approvedByUserId;
    @JsonKey(name: 'company_business_name',)
    String companyBusinessName;
    @JsonKey(name: 'current_address',)
    String currentAddress;
    @JsonKey(name: 'current_place_id',)
    String currentPlaceId;
    @JsonKey(name: 'father_in_law_name',)
    String fatherInLawName;
    @JsonKey(name: 'father_in_law_place_id',)
    String fatherInLawPlaceId;
    @JsonKey(name: 'first_name',)
    String firstName;
    @JsonKey(name: 'id',)
    String id;
    @JsonKey(name: 'image',)
    String image;
    @JsonKey(name: 'last_name',)
    String lastName;
    @JsonKey(name: 'middle_name',)
    String middleName;
    @JsonKey(name: 'native_address',)
    String nativeAddress;
    @JsonKey(name: 'native_place_id',)
    String nativePlaceId;
    @JsonKey(name: 'phone',)
    String phone;
    @JsonKey(name: 'birth_date',)
    DateTime birthDate;
    @JsonKey(name: 'current_place',)
    Place currentPlace;
    @JsonKey(name: 'father_in_law_place',)
    Place fatherInLawPlace;
    @JsonKey(name: 'native_place',)
    Place nativePlace;
    @JsonKey(name: 'created_at',)
    DateTime createdAt;
    @JsonKey(name: 'updated_at',)
    DateTime updatedAt;
    @JsonKey(name: 'birth_time', fromJson: _timeOfDayFromString,)
    TimeOfDay birthTime;
    @JsonKey(name: 'user_approval_requests',)
    List<UserApprovalRequest> userApprovalRequests;
    @JsonKey(name: 'user_approval_requests_aggregate',)
    UserApprovalRequestsAggregate userApprovalRequestsAggregate;
    @JsonKey(name: 'user_educations',)
    List<UserEducation> userEducations;
    @JsonKey(name: 'user_educations_aggregate',)
    UserEducationsAggregate userEducationsAggregate;
    @JsonKey(name: 'user_families',)
    List<UserFamily> userFamilies;
    @JsonKey(name: 'user_families_aggregate',)
    UserFamiliesAggregate userFamiliesAggregate;
    @JsonKey(name: 'user_occupations',)
    List<UserOccupation> userOccupations;
    @JsonKey(name: 'user_occupations_aggregate',)
    UserOccupationsAggregate userOccupationsAggregate;

    User({
        this.isApproved,            
        this.isRegistrationCompleted,            
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
        this.approvedByUserId,            
        this.companyBusinessName,            
        this.currentAddress,            
        this.currentPlaceId,            
        this.fatherInLawName,            
        this.fatherInLawPlaceId,            
        this.firstName,            
        this.id,            
        this.image,            
        this.lastName,            
        this.middleName,            
        this.nativeAddress,            
        this.nativePlaceId,            
        this.phone,            
        this.birthDate,            
        this.currentPlace,            
        this.fatherInLawPlace,            
        this.nativePlace,            
        this.createdAt,            
        this.updatedAt,            
        this.birthTime,            
        this.userApprovalRequests,            
        this.userApprovalRequestsAggregate,            
        this.userEducations,            
        this.userEducationsAggregate,            
        this.userFamilies,            
        this.userFamiliesAggregate,            
        this.userOccupations,            
        this.userOccupationsAggregate,            
    });

    factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
}

@JsonSerializable()
class UsersAggregate {
    @JsonKey(name: 'nodes',)
    List<User> nodes;
    @JsonKey(name: 'aggregate',)
    UsersAggregateField aggregate;

    UsersAggregate({
        this.nodes,            
        this.aggregate,            
    });

    factory UsersAggregate.fromJson(Map<String, dynamic> json) => _$UsersAggregateFromJson(json);
}

@JsonSerializable()
class UsersAggregateField {
    @JsonKey(name: 'count',)
    int count;
    @JsonKey(name: 'avg',)
    UsersAvgField avg;
    @JsonKey(name: 'max',)
    UsersMaxField max;
    @JsonKey(name: 'min',)
    UsersMinField min;
    @JsonKey(name: 'stddev',)
    UsersStddevField stddev;
    @JsonKey(name: 'stddev_pop',)
    UsersStddevPopField stddevPop;
    @JsonKey(name: 'stddev_samp',)
    UsersStddevSampField stddevSamp;
    @JsonKey(name: 'sum',)
    UsersSumField sum;
    @JsonKey(name: 'var_pop',)
    UsersVarPopField varPop;
    @JsonKey(name: 'var_samp',)
    UsersVarSampField varSamp;
    @JsonKey(name: 'variance',)
    UsersVarianceField variance;

    UsersAggregateField({
        this.count,            
        this.avg,            
        this.max,            
        this.min,            
        this.stddev,            
        this.stddevPop,            
        this.stddevSamp,            
        this.sum,            
        this.varPop,            
        this.varSamp,            
        this.variance,            
    });

    factory UsersAggregateField.fromJson(Map<String, dynamic> json) => _$UsersAggregateFieldFromJson(json);
}

@JsonSerializable()
class UsersAvgField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersAvgField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersAvgField.fromJson(Map<String, dynamic> json) => _$UsersAvgFieldFromJson(json);
}

@JsonSerializable()
class UsersMaxField {
    @JsonKey(name: 'blood_group',)
    int bloodGroup;
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'marital_status',)
    int maritalStatus;
    @JsonKey(name: 'approved_by_user_id',)
    String approvedByUserId;
    @JsonKey(name: 'company_business_name',)
    String companyBusinessName;
    @JsonKey(name: 'current_address',)
    String currentAddress;
    @JsonKey(name: 'current_place_id',)
    String currentPlaceId;
    @JsonKey(name: 'father_in_law_name',)
    String fatherInLawName;
    @JsonKey(name: 'father_in_law_place_id',)
    String fatherInLawPlaceId;
    @JsonKey(name: 'first_name',)
    String firstName;
    @JsonKey(name: 'id',)
    String id;
    @JsonKey(name: 'image',)
    String image;
    @JsonKey(name: 'last_name',)
    String lastName;
    @JsonKey(name: 'middle_name',)
    String middleName;
    @JsonKey(name: 'native_address',)
    String nativeAddress;
    @JsonKey(name: 'native_place_id',)
    String nativePlaceId;
    @JsonKey(name: 'phone',)
    String phone;
    @JsonKey(name: 'birth_date',)
    DateTime birthDate;
    @JsonKey(name: 'created_at',)
    DateTime createdAt;
    @JsonKey(name: 'updated_at',)
    DateTime updatedAt;
    @JsonKey(name: 'birth_time', fromJson: _timeOfDayFromString,)
    TimeOfDay birthTime;

    UsersMaxField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
        this.approvedByUserId,            
        this.companyBusinessName,            
        this.currentAddress,            
        this.currentPlaceId,            
        this.fatherInLawName,            
        this.fatherInLawPlaceId,            
        this.firstName,            
        this.id,            
        this.image,            
        this.lastName,            
        this.middleName,            
        this.nativeAddress,            
        this.nativePlaceId,            
        this.phone,            
        this.birthDate,            
        this.createdAt,            
        this.updatedAt,            
        this.birthTime,            
    });

    factory UsersMaxField.fromJson(Map<String, dynamic> json) => _$UsersMaxFieldFromJson(json);
}

@JsonSerializable()
class UsersMinField {
    @JsonKey(name: 'blood_group',)
    int bloodGroup;
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'marital_status',)
    int maritalStatus;
    @JsonKey(name: 'approved_by_user_id',)
    String approvedByUserId;
    @JsonKey(name: 'company_business_name',)
    String companyBusinessName;
    @JsonKey(name: 'current_address',)
    String currentAddress;
    @JsonKey(name: 'current_place_id',)
    String currentPlaceId;
    @JsonKey(name: 'father_in_law_name',)
    String fatherInLawName;
    @JsonKey(name: 'father_in_law_place_id',)
    String fatherInLawPlaceId;
    @JsonKey(name: 'first_name',)
    String firstName;
    @JsonKey(name: 'id',)
    String id;
    @JsonKey(name: 'image',)
    String image;
    @JsonKey(name: 'last_name',)
    String lastName;
    @JsonKey(name: 'middle_name',)
    String middleName;
    @JsonKey(name: 'native_address',)
    String nativeAddress;
    @JsonKey(name: 'native_place_id',)
    String nativePlaceId;
    @JsonKey(name: 'phone',)
    String phone;
    @JsonKey(name: 'birth_date',)
    DateTime birthDate;
    @JsonKey(name: 'created_at',)
    DateTime createdAt;
    @JsonKey(name: 'updated_at',)
    DateTime updatedAt;
    @JsonKey(name: 'birth_time', fromJson: _timeOfDayFromString,)
    TimeOfDay birthTime;

    UsersMinField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
        this.approvedByUserId,            
        this.companyBusinessName,            
        this.currentAddress,            
        this.currentPlaceId,            
        this.fatherInLawName,            
        this.fatherInLawPlaceId,            
        this.firstName,            
        this.id,            
        this.image,            
        this.lastName,            
        this.middleName,            
        this.nativeAddress,            
        this.nativePlaceId,            
        this.phone,            
        this.birthDate,            
        this.createdAt,            
        this.updatedAt,            
        this.birthTime,            
    });

    factory UsersMinField.fromJson(Map<String, dynamic> json) => _$UsersMinFieldFromJson(json);
}

@JsonSerializable()
class UsersStddevField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersStddevField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersStddevField.fromJson(Map<String, dynamic> json) => _$UsersStddevFieldFromJson(json);
}

@JsonSerializable()
class UsersStddevPopField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersStddevPopField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersStddevPopField.fromJson(Map<String, dynamic> json) => _$UsersStddevPopFieldFromJson(json);
}

@JsonSerializable()
class UsersStddevSampField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersStddevSampField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersStddevSampField.fromJson(Map<String, dynamic> json) => _$UsersStddevSampFieldFromJson(json);
}

@JsonSerializable()
class UsersSumField {
    @JsonKey(name: 'blood_group',)
    int bloodGroup;
    @JsonKey(name: 'gender',)
    int gender;
    @JsonKey(name: 'marital_status',)
    int maritalStatus;

    UsersSumField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersSumField.fromJson(Map<String, dynamic> json) => _$UsersSumFieldFromJson(json);
}

@JsonSerializable()
class UsersVarPopField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersVarPopField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersVarPopField.fromJson(Map<String, dynamic> json) => _$UsersVarPopFieldFromJson(json);
}

@JsonSerializable()
class UsersVarSampField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersVarSampField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersVarSampField.fromJson(Map<String, dynamic> json) => _$UsersVarSampFieldFromJson(json);
}

@JsonSerializable()
class UsersVarianceField {
    @JsonKey(name: 'blood_group',)
    double bloodGroup;
    @JsonKey(name: 'gender',)
    double gender;
    @JsonKey(name: 'marital_status',)
    double maritalStatus;

    UsersVarianceField({
        this.bloodGroup,            
        this.gender,            
        this.maritalStatus,            
    });

    factory UsersVarianceField.fromJson(Map<String, dynamic> json) => _$UsersVarianceFieldFromJson(json);
}

@JsonSerializable()
class GQLMutationData {
    @JsonKey(name: 'delete_educations',)
    EducationsMutationResponse deleteEducations;
    @JsonKey(name: 'insert_educations',)
    EducationsMutationResponse insertEducations;
    @JsonKey(name: 'update_educations',)
    EducationsMutationResponse updateEducations;
    @JsonKey(name: 'delete_occupations',)
    OccupationsMutationResponse deleteOccupations;
    @JsonKey(name: 'insert_occupations',)
    OccupationsMutationResponse insertOccupations;
    @JsonKey(name: 'update_occupations',)
    OccupationsMutationResponse updateOccupations;
    @JsonKey(name: 'delete_places',)
    PlacesMutationResponse deletePlaces;
    @JsonKey(name: 'insert_places',)
    PlacesMutationResponse insertPlaces;
    @JsonKey(name: 'update_places',)
    PlacesMutationResponse updatePlaces;
    @JsonKey(name: 'delete_relations',)
    RelationsMutationResponse deleteRelations;
    @JsonKey(name: 'insert_relations',)
    RelationsMutationResponse insertRelations;
    @JsonKey(name: 'update_relations',)
    RelationsMutationResponse updateRelations;
    @JsonKey(name: 'delete_user_approval_requests',)
    UserApprovalRequestsMutationResponse deleteUserApprovalRequests;
    @JsonKey(name: 'insert_user_approval_requests',)
    UserApprovalRequestsMutationResponse insertUserApprovalRequests;
    @JsonKey(name: 'update_user_approval_requests',)
    UserApprovalRequestsMutationResponse updateUserApprovalRequests;
    @JsonKey(name: 'delete_user_educations',)
    UserEducationsMutationResponse deleteUserEducations;
    @JsonKey(name: 'insert_user_educations',)
    UserEducationsMutationResponse insertUserEducations;
    @JsonKey(name: 'update_user_educations',)
    UserEducationsMutationResponse updateUserEducations;
    @JsonKey(name: 'delete_user_families',)
    UserFamiliesMutationResponse deleteUserFamilies;
    @JsonKey(name: 'insert_user_families',)
    UserFamiliesMutationResponse insertUserFamilies;
    @JsonKey(name: 'update_user_families',)
    UserFamiliesMutationResponse updateUserFamilies;
    @JsonKey(name: 'delete_user_occupations',)
    UserOccupationsMutationResponse deleteUserOccupations;
    @JsonKey(name: 'insert_user_occupations',)
    UserOccupationsMutationResponse insertUserOccupations;
    @JsonKey(name: 'update_user_occupations',)
    UserOccupationsMutationResponse updateUserOccupations;
    @JsonKey(name: 'delete_users',)
    UsersMutationResponse deleteUsers;
    @JsonKey(name: 'insert_users',)
    UsersMutationResponse insertUsers;
    @JsonKey(name: 'update_users',)
    UsersMutationResponse updateUsers;

    GQLMutationData({
        this.deleteEducations,            
        this.insertEducations,            
        this.updateEducations,            
        this.deleteOccupations,            
        this.insertOccupations,            
        this.updateOccupations,            
        this.deletePlaces,            
        this.insertPlaces,            
        this.updatePlaces,            
        this.deleteRelations,            
        this.insertRelations,            
        this.updateRelations,            
        this.deleteUserApprovalRequests,            
        this.insertUserApprovalRequests,            
        this.updateUserApprovalRequests,            
        this.deleteUserEducations,            
        this.insertUserEducations,            
        this.updateUserEducations,            
        this.deleteUserFamilies,            
        this.insertUserFamilies,            
        this.updateUserFamilies,            
        this.deleteUserOccupations,            
        this.insertUserOccupations,            
        this.updateUserOccupations,            
        this.deleteUsers,            
        this.insertUsers,            
        this.updateUsers,            
    });

    factory GQLMutationData.fromJson(Map<String, dynamic> json) => _$GQLMutationDataFromJson(json);
}

@JsonSerializable()
class EducationsMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<Education> returning;

    EducationsMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory EducationsMutationResponse.fromJson(Map<String, dynamic> json) => _$EducationsMutationResponseFromJson(json);
}

@JsonSerializable()
class OccupationsMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<Occupation> returning;

    OccupationsMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory OccupationsMutationResponse.fromJson(Map<String, dynamic> json) => _$OccupationsMutationResponseFromJson(json);
}

@JsonSerializable()
class PlacesMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<Place> returning;

    PlacesMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory PlacesMutationResponse.fromJson(Map<String, dynamic> json) => _$PlacesMutationResponseFromJson(json);
}

@JsonSerializable()
class RelationsMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<Relation> returning;

    RelationsMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory RelationsMutationResponse.fromJson(Map<String, dynamic> json) => _$RelationsMutationResponseFromJson(json);
}

@JsonSerializable()
class UserApprovalRequestsMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<UserApprovalRequest> returning;

    UserApprovalRequestsMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory UserApprovalRequestsMutationResponse.fromJson(Map<String, dynamic> json) => _$UserApprovalRequestsMutationResponseFromJson(json);
}

@JsonSerializable()
class UserEducationsMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<UserEducation> returning;

    UserEducationsMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory UserEducationsMutationResponse.fromJson(Map<String, dynamic> json) => _$UserEducationsMutationResponseFromJson(json);
}

@JsonSerializable()
class UserFamiliesMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<UserFamily> returning;

    UserFamiliesMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory UserFamiliesMutationResponse.fromJson(Map<String, dynamic> json) => _$UserFamiliesMutationResponseFromJson(json);
}

@JsonSerializable()
class UserOccupationsMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<UserOccupation> returning;

    UserOccupationsMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory UserOccupationsMutationResponse.fromJson(Map<String, dynamic> json) => _$UserOccupationsMutationResponseFromJson(json);
}

@JsonSerializable()
class UsersMutationResponse {
    @JsonKey(name: 'affected_rows',)
    int affectedRows;
    @JsonKey(name: 'returning',)
    List<User> returning;

    UsersMutationResponse({
        this.affectedRows,            
        this.returning,            
    });

    factory UsersMutationResponse.fromJson(Map<String, dynamic> json) => _$UsersMutationResponseFromJson(json);
}

@JsonSerializable()
class GQLSubscriptionData {
    @JsonKey(name: 'educations',)
    List<Education> educations;
    @JsonKey(name: 'educations_by_pk',)
    Education educationsByPk;
    @JsonKey(name: 'educations_aggregate',)
    EducationsAggregate educationsAggregate;
    @JsonKey(name: 'occupations',)
    List<Occupation> occupations;
    @JsonKey(name: 'occupations_by_pk',)
    Occupation occupationsByPk;
    @JsonKey(name: 'occupations_aggregate',)
    OccupationsAggregate occupationsAggregate;
    @JsonKey(name: 'places',)
    List<Place> places;
    @JsonKey(name: 'places_by_pk',)
    Place placesByPk;
    @JsonKey(name: 'places_aggregate',)
    PlacesAggregate placesAggregate;
    @JsonKey(name: 'relations',)
    List<Relation> relations;
    @JsonKey(name: 'relations_by_pk',)
    Relation relationsByPk;
    @JsonKey(name: 'relations_aggregate',)
    RelationsAggregate relationsAggregate;
    @JsonKey(name: 'user_approval_requests',)
    List<UserApprovalRequest> userApprovalRequests;
    @JsonKey(name: 'user_approval_requests_by_pk',)
    UserApprovalRequest userApprovalRequestsByPk;
    @JsonKey(name: 'user_approval_requests_aggregate',)
    UserApprovalRequestsAggregate userApprovalRequestsAggregate;
    @JsonKey(name: 'user_educations',)
    List<UserEducation> userEducations;
    @JsonKey(name: 'user_educations_by_pk',)
    UserEducation userEducationsByPk;
    @JsonKey(name: 'user_educations_aggregate',)
    UserEducationsAggregate userEducationsAggregate;
    @JsonKey(name: 'user_families',)
    List<UserFamily> userFamilies;
    @JsonKey(name: 'user_families_by_pk',)
    UserFamily userFamiliesByPk;
    @JsonKey(name: 'user_families_aggregate',)
    UserFamiliesAggregate userFamiliesAggregate;
    @JsonKey(name: 'user_occupations',)
    List<UserOccupation> userOccupations;
    @JsonKey(name: 'user_occupations_by_pk',)
    UserOccupation userOccupationsByPk;
    @JsonKey(name: 'user_occupations_aggregate',)
    UserOccupationsAggregate userOccupationsAggregate;
    @JsonKey(name: 'users',)
    List<User> users;
    @JsonKey(name: 'users_by_pk',)
    User usersByPk;
    @JsonKey(name: 'users_aggregate',)
    UsersAggregate usersAggregate;

    GQLSubscriptionData({
        this.educations,            
        this.educationsByPk,            
        this.educationsAggregate,            
        this.occupations,            
        this.occupationsByPk,            
        this.occupationsAggregate,            
        this.places,            
        this.placesByPk,            
        this.placesAggregate,            
        this.relations,            
        this.relationsByPk,            
        this.relationsAggregate,            
        this.userApprovalRequests,            
        this.userApprovalRequestsByPk,            
        this.userApprovalRequestsAggregate,            
        this.userEducations,            
        this.userEducationsByPk,            
        this.userEducationsAggregate,            
        this.userFamilies,            
        this.userFamiliesByPk,            
        this.userFamiliesAggregate,            
        this.userOccupations,            
        this.userOccupationsByPk,            
        this.userOccupationsAggregate,            
        this.users,            
        this.usersByPk,            
        this.usersAggregate,            
    });

    factory GQLSubscriptionData.fromJson(Map<String, dynamic> json) => _$GQLSubscriptionDataFromJson(json);
}

@JsonSerializable()
class GQLQuery {
    @JsonKey(name: 'data')
    GQLQueryData data;
    @JsonKey(name: 'errors')
    List<GQLError> errors;

    GQLQuery({
        this.data,
        this.errors,
    });

    factory GQLQuery.fromJson(Map<String, dynamic> json) => _$GQLQueryFromJson(json);
}

@JsonSerializable()
class GQLMutation {
    @JsonKey(name: 'data')
    GQLMutationData data;
    @JsonKey(name: 'errors')
    List<GQLError> errors;

    GQLMutation({
        this.data,
        this.errors,
    });

    factory GQLMutation.fromJson(Map<String, dynamic> json) => _$GQLMutationFromJson(json);
}

@JsonSerializable()
class GQLSubscription {
    @JsonKey(name: 'data')
    GQLSubscriptionData data;
    @JsonKey(name: 'errors')
    List<GQLError> errors;

    GQLSubscription({
        this.data,
        this.errors,
    });

    factory GQLSubscription.fromJson(Map<String, dynamic> json) => _$GQLSubscriptionFromJson(json);
}

@JsonSerializable()
class GQLError {
    @JsonKey(name: 'message')
    String message;

    GQLError({
        this.message,
    });

    factory GQLError.fromJson(Map<String, dynamic> json) => _$GQLErrorFromJson(json);
}

TimeOfDay _timeOfDayFromString(String timetz) => TimeOfDay(hour: int.parse(timetz.split(":")[0]), minute: int.parse(timetz.split(":")[1]));
