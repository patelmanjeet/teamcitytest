var { schemaToTemplateContext } = require('graphql-codegen-core');
var handlebars = require('handlebars');
var fs = require('fs')
var pluralize = require('pluralize')
var _ = require('lodash');

handlebars.registerHelper("sortFields", function(fields) {
    return _.sortBy(fields,['type','name'])    
});

handlebars.registerHelper("className", function(name) {
    if( name == 'query_root') return 'GQLQueryData';
    if( name == 'mutation_root') return 'GQLMutationData';
    if( name == 'subscription_root') return 'GQLSubscriptionData';
    
    return _.upperFirst(_.camelCase(pluralize.singular(name)));
});

handlebars.registerHelper("fieldName", function(name) {
    return _.camelCase(name);
});

handlebars.registerHelper("jsonKey", function(name,type) {
    if( type == 'timetz' ) 
	return "@JsonKey(name: '" + name + "', fromJson: _timeOfDayFromString,)";
    else    
	return "@JsonKey(name: \'" + name + "\',)";   
});

handlebars.registerHelper("resolveType", function(type) {     
    var primitives = {
        String: 'String',
        Int: 'int',
        numeric: 'double', 
        Float: 'double',
        Boolean: 'bool',                    
        timestamptz: 'DateTime',
        timetz: 'TimeOfDay',
        date: 'DateTime',
	json: 'var',
	jsonb: 'var',
    }

    if (type in primitives) { 
        var returnType = primitives[type];    
    } else {
        // custom classess
        var returnType = _.upperFirst(_.camelCase(pluralize.singular(type)));        
    }
    
    return returnType;
});
  
module.exports = {
  plugin: (schema, documents, config) => {

    var templateContext = schemaToTemplateContext(schema);

    var content = fs.readFileSync("main.handlebars", 'utf-8');    
    var template = handlebars.compile(content);
    return template(templateContext);
  }
};
